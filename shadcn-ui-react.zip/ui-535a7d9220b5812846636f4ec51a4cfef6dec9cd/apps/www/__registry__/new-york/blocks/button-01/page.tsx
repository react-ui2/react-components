import { AmazingButton } from "@/registry/new-york/blocks/button-01/components/amazing-button"

export default function Page() {
  return (
    <div className="h-svh flex items-center justify-center">
      <AmazingButton />
    </div>
  )
}
