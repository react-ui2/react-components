---
"shadcn": minor
---

add warning for deprecated components
