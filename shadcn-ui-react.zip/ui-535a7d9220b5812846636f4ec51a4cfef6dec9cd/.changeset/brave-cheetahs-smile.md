---
"shadcn": minor
---

add support for TanStack Start
