---
"shadcn": patch
---

do not overwrite user defined vars
