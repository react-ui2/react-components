---
"shadcn": minor
---

add tailwind version detection
