---
"shadcn": patch
---

fix cn import bug in monorepo
