---
"shadcn": minor
---

add support for tailwind v4
