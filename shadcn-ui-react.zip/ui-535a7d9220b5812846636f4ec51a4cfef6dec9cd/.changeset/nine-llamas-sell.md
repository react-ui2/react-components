---
"shadcn": minor
---

fix handling of sidebar colors
