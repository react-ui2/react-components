---
"shadcn": patch
---

upgrade @antfu/ni
