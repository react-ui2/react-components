---
"shadcn": patch
---

filter out deprecated from --all
