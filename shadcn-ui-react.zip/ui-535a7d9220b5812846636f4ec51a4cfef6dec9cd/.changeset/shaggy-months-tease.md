---
"shadcn": patch
---

check for empty css vars
