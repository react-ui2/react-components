---
"shadcn": minor
---

default to css vars. add --no-css-variables
