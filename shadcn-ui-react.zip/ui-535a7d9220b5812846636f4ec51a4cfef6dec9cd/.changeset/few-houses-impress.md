---
"shadcn": minor
---

add theme vars support
