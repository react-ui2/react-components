---
"shadcn": patch
---

cache registry calls
