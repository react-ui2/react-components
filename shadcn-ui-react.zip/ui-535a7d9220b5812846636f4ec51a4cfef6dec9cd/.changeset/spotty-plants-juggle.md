---
"shadcn": patch
---

fix tanstack check
